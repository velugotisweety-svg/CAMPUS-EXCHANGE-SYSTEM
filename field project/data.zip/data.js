const items = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 1200,
    condition: "Like New",
    seller: "Rahul",
    phone: "9876543210",
    image: "https://images.unsplash.com/photo-1518441902117-f1d1b2e3b8a0?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    name: "Bluetooth Speaker",
    price: 900,
    condition: "Used",
    seller: "Anjali",
    phone: "9123456780",
    image: "https://images.unsplash.com/photo-1585386959984-a41552262c07?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    name: "Laptop Stand",
    price: 500,
    condition: "Good",
    seller: "Suresh",
    phone: "9988776655",
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 4,
    name: "Operating Systems Book",
    price: 350,
    condition: "Good",
    seller: "Divya",
    phone: "9012345678",
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 5,
    name: "Study Chair",
    price: 900,
    condition: "Used",
    seller: "Amit",
    phone: "9090909090",
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 6,
    name: "Lunch Box Set",
    price: 300,
    condition: "Good",
    seller: "Pooja",
    phone: "8899776655",
    image: "https://images.unsplash.com/photo-1604908817752-9378fa5d7f32?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 7,
    name: "Electric Kettle",
    price: 800,
    condition: "Used",
    seller: "Kiran",
    phone: "9345678123",
    image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80"
  }
];
